## File Structures

These are the file structures for .base, .aux and .ppd files.

They are not complete as I only searched until I had everything I needed.

They are for the current version of the game V1.35 (base/aux file ver. 869, ppd ver. 22)

They are made using [010 editor](https://www.sweetscape.com/010editor/), but if you just want to see the structures you can just read them in a text editor.

If you are using 010 editor, use base-template.bt with .base files and aux-template.bt with aux files.
